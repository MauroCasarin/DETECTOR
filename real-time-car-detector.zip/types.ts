
export type BoundingBox = [number, number, number, number]; // [ymin, xmin, ymax, xmax]
